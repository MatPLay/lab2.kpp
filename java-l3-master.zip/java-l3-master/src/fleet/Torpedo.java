package fleet;

public class Torpedo {
	public void blow() {
		
	}
}
