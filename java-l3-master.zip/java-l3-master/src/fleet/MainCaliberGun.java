package fleet;

public class MainCaliberGun extends Gun {

	public MainCaliberGun(int caliber, int barrelLength) {
		super(caliber, barrelLength);
	}

	@Override
	public void shoot() {

	}

}
