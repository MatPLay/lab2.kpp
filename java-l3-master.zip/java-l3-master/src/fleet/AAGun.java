package fleet;

public class AAGun extends Gun {

	public AAGun(int caliber, int barrelLength) {
		super(caliber, barrelLength);
	}

	@Override
	public void shoot() {

	}

}
